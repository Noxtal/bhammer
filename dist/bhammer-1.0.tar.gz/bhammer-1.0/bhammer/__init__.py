__version__ = '1.0'
__description__ = 'Python tool to create an ASCII art banner for a command line tool.'
__url__ = 'https://github.com/Noxtal/bhammer'
