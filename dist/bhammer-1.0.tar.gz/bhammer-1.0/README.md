# bhammer

This is a Python tool to create an ASCII art banner for a command line tool.

## Usage
### Install

``` sh
$ pip install bhammer
```
### How to use
Run the program and input the necessary information:
```sh
python -m bhammer
```

For more things I did, see my [website](https://www.noxtal.com).
